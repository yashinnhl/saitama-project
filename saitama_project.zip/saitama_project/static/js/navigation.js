var adminaccess;
$.ajaxSetup({ cache: false });
$.ajax({
    url:'static/admin/cpanel.html',
    type:'HEAD',
    error: function()
    {
       adminaccess = false;
    },
    success: function()
    {
       adminaccess = true;
    }
});

var realnav = [];
var modcurr = [];
var completed = false;
var curr = 1;
var progression = [];
var realprogress = [];
$.ajax({
    url: 'static/data/coursedata.json',
    dataType: 'json',
    cache:false,
    success: function( data ) {

        var totalslides = data.slides.length;

        $(document).ready(function(){
        function repnav(){
        var titleslide = data.slides[curr-1].title;
        $('#contenu').hide();
        $('#contenu').html("<div id='slideContent'>"+data.slides[curr-1].content+"</div>");
        $('#contenu').fadeIn(400);
        $("#pagernumber").html("<span>"+data.nav[2].text+"&nbsp;"+curr+"&nbsp;"+ data.nav[3].text+ "&nbsp;"+totalslides+"</span>"+"&nbsp;&nbsp;"+data.menus[modcurr[curr-1]].title+" > "+titleslide+"</span>");
        $("#slidetitle").html(data.slides[curr-1].title);
        progression.push(realnav[curr-1]);

        $(function(){
        $('[data-toggle="popover"]').popover()
        });           
         // do admin multiple
        if (adminaccess === true){

            var features=[{"name":"Paragraph","code":"<p>Your Text Here</p>","category":"grid"},{"name":"Left Aligned Paragraph","code":"<p class='text-left'>Your centre aligned paragraph.</p>","category":"grid"},{"name":"Centre Aligned Paragraph","code":"<p class='text-center'>Your centre aligned paragraph.</p>","category":"grid"},{"name":"Right Aligned Paragraph","code":"<p class='text-right'>Your centre aligned paragraph.</p>","category":"grid"},{"name":"Titles","code":"<h4>Your Text Here</h4>","category":"txtstyle"},{"name":"Italics","code":"<i>Your Text Here</i>","category":"txtstyle"},{"name":"Bold","code":"<b>Your Text Here</b>","category":"txtstyle"},{"name":"Underline","code":"<u>Your Text Here</u>","category":"txtstyle"},{"name":"Bullet List","code":"<ul><li>List Item #1</li> <li>List Item #2</li> <li>List Item #3</li></ul>","category":"txtstyle"},{"name":"Numbered List","code":"<ol><li>List Item #1</li> <li>List Item #2</li> <li>List Item #3</li></ol>","category":"txtstyle"},{"name":"Responsive Image","code":"<img src='media/img/ImageFileName.jpg' class='img-responsive' alt='Your Image Description'>","category":"media"},{"name":"Lightbox Image","code":"<div class='row'><div class='col-xs-6 col-md-3'>  <a href='media/img/ImageFileName.jpg' class='thumbnail' data-lity data-lity-desc='Your Image Description'>   <img src='media/img/ImageFileName.jpg' alt='Your Image Description'>  </a> </div></div>","category":"media"},{"name":"Glyphicon Icons","code":"<span class='glyphicon glyphicon-globe'></span><a href='http://getbootstrap.com/components/#glyphicons-glyphs'>More Glyphicon Codes Here</a>","category":"media"},{"name":"Autoplay Audio Clip","code":"<audio controls autoplay><source src='media/audio/YourAudioClipFileName.mp3' type='audio/mpeg'>Your browser does not support the audio element.</audio>","category":"media"},{"name":"Manual Audio Clip","code":"<audio controls><source src='media/audio/YourAudioClipFileName.mp3' type='audio/mpeg'>Your browser does not support the audio element.</audio>","category":"media"},{"name":"HTML5 Video Player","code":"<video id='video' controls preload='metadata'><source src='media/video/test.mp4' type='video/mp4'><track label='English' kind='subtitles' srclang='en' src='media/video/captions/subs.vtt' default></video> ","category":"media"},{"name":"Accordion","code":"<div class='panel-group' id='accordion'><div class='panel panel-default'><div class='panel-heading'><h4 class='panel-title'><a data-toggle='collapse' data-parent='#accordion' href='#collapse1'>TITLE #1</a></h4></div><div id='collapse1' class='panel-collapse collapse in'><div class='panel-body'>Your content in collapsable box #1</div></div></div><div class='panel panel-default'><div class='panel-heading'><h4 class='panel-title'><a data-toggle='collapse' data-parent='#accordion' href='#collapse2'>TITLE #2</a></h4></div><div id='collapse2' class='panel-collapse collapse'><div class='panel-body'>Your content in collapsable box #1</div></div></div><div class='panel panel-default'><div class='panel-heading'><h4 class='panel-title'><a data-toggle='collapse' data-parent='#accordion' href='#collapse3'>TITLE #3</a></h4></div><div id='collapse3' class='panel-collapse collapse'><div class='panel-body'>Your content in collapsable box #1</div></div></div></div>","category":"interaction"},{"name":"Jumbotron","code":"<div class='jumbotron'><h1>Your Title Here</h1><p>You can write the Jumbotron paragraph here!</p></div>","category":"txtbox"},{"name":"External Link","code":"<a href='http://www.w3schools.com' target='_blank'>Link Name<span class='glyphicon glyphicon-globe'></span></a>","category":"interaction"},{"name":"Popover","code":"<a tabindex='0' class='btn btn-lg btn-danger' role='button'data-toggle='popover' data-trigger='focus' title='Dismissible popover'data-content='Click anywhere to dismiss this popover'>Dismissible popover</a>","category":"interaction"},{"name":"2 Columns","code":"<div class='row'><div class='col-md-6'>This is one column that takes up half the space.</div><div class='col-md-6'>This is the second column that takes up half the space.</div></div>","category":"grid"},{"name":"3 Columns","code":"<div class='row'><div class='col-md-4'>This is one column that takes up a third of the space.</div><div class='col-md-4'>This is the second column that takes up a third of the space.</div><div class='col-md-4'>This is the last column that takes up a third of the space.</div></div>","category":"grid"},{"name":"Infinite Bounce Animation","code":"<div class='bounce'>Your Content Here</div>","category":"animation"},{"name":"Slide in from Left Animation","code":"<div class='slideInLeft'>Your Content Here</div>","category":"animation"},{"name":"Slide in from Right Animation","code":"<div class='slideInRight'>Your Content Here</div>","category":"animation"},{"name":"Slide in from Top Animation","code":"<div class='slideInTop'>Your Content Here</div>","category":"animation"},{"name":"Slide in from Bottom Animation","code":"<div class='slideInBottom'>Your Content Here</div>","category":"animation"},{"name":"Fade In Animation","code":"<div class='fadeIn'>Your Content Here</div>","category":"animation"},{"name":"Note Box","code":"<div class='media' style='background-color:rgba(250,199,27,0.3); padding:10px; border-radius:15px;'><div class='media-left'><i class='fa fa-lightbulb-o fa-4x' aria-hidden='true' style='padding:10px; border-right:2px solid rgba(0,0,0,0.2)''></i></div><div class='media-body'><h4 class='media-heading'>Heading</h4>Your content goes here</div></div>","category":"txtbox"},{"name":"Key Concepts Box","code":"<div class='media' style='background-color:rgba(250,162,27,0.3); padding:10px; border-radius:15px;'><div class='media-left'> <i class='fa fa-key fa-4x' aria-hidden='true' style='padding:10px; border-right:2px solid rgba(0,0,0,0.2)'></i></div><div class='media-body'><h4 class='media-heading'>Heading</h4>Your content goes here</div></div>","category":"txtbox"},{"name":"Important Box","code":"<div class='media' style='background-color:rgba(242,101,34,0.3); padding:10px; border-radius:15px;'><div class='media-left'><i class='fa fa-exclamation-triangle fa-4x' aria-hidden='true' style='padding:10px; border-right:2px solid rgba(0,0,0,0.2)''></i></div><div class='media-body'><h4 class='media-heading'>Heading</h4>Your content goes here</div></div>","category":"txtbox"},{"name":"Activity Box","code":"<div class='media' style='background-color:rgba(229,128,174,0.3); padding:10px; border-radius:15px;'><div class='media-left'><i class='fa fa-flag fa-4x' aria-hidden='true' style='padding:10px; border-right:2px solid rgba(0,0,0,0.2)''></i></div><div class='media-body'><h4 class='media-heading'>Heading</h4>Your content goes here</div></div>","category":"txtbox"},{"name":"Test Box","code":"<div class='media' style='background-color:rgba(4,184,237,0.3); padding:10px; border-radius:15px;'><div class='media-left'><i class='fa fa-pencil-square-o fa-4x' aria-hidden='true' style='padding:10px; border-right:2px solid rgba(0,0,0,0.2)''></i></div><div class='media-body'><h4 class='media-heading'>Heading</h4>Your content goes here</div></div>","category":"txtbox"},{"name":"Go To Box","code":"<div class='media' style='background-color:rgba(0,120,184,0.3); padding:10px; border-radius:15px;'><div class='media-left'><span class='glyphicon glyphicon-share-alt' aria-hidden='true' style='padding:10px; border-right:2px solid rgba(0,0,0,0.2); font-size:50px'></span></i></div><div class='media-body'><h4 class='media-heading'>Heading</h4>Your content goes here</div></div>","category":"txtbox"},{"name":"Calculation Box","code":"<div class='media' style='background-color:rgba(0,165,116,0.3); padding:10px; border-radius:15px;'><div class='media-left'><i class='fa fa-calculator fa-4x' aria-hidden='true' style='padding:10px; border-right:2px solid rgba(0,0,0,0.2)''></i></div><div class='media-body'><h4 class='media-heading'>Heading</h4>Your content goes here</div></div>","category":"txtbox"}];

              $('#contenu').append('<br /><div class="btn-group" role="group" aria-label="..." id="controls"></div><br />');

              $('#controls').append('<div class="btn-group" role="group"><button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-font">&nbsp;</span><span class="caret"></span></button><ul class="dropdown-menu" id="txtstyle"></ul></div>');
              $('#controls').append('<div class="btn-group" role="group"><button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-facetime-video">&nbsp;</span><span class="caret"></span></button><ul class="dropdown-menu" id="media"></ul></div>');
              $('#controls').append('<div class="btn-group" role="group"><button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-send">&nbsp;</span><span class="caret"></span></button><ul class="dropdown-menu" id="animation"></ul></div>');
              $('#controls').append('<div class="btn-group" role="group"><button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-align-justify">&nbsp;</span><span class="caret"></span></button><ul class="dropdown-menu" id="grid"></ul></div>');
              $('#controls').append('<div class="btn-group" role="group"><button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-text-background">&nbsp;</span><span class="caret"></span></button><ul class="dropdown-menu" id="txtbox"></ul></div>');
              $('#controls').append('<div class="btn-group" role="group"><button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-hand-up">&nbsp;</span><span class="caret"></span></button><ul class="dropdown-menu" id="interaction"></ul></div>');

              $.each(features, function(k){
                if (features[k].category == "txtstyle"){
                    $('#txtstyle').append('<li><a data-value="'+k+'">'+features[k].name+'</a></li>')
                };
                if (features[k].category == "animation"){
                    $('#animation').append('<li><a data-value="'+k+'">'+features[k].name+'</a></li>')
                };
                if (features[k].category == "interaction"){
                    $('#interaction').append('<li><a data-value="'+k+'">'+features[k].name+'</a></li>')
                };
                if (features[k].category == "grid"){
                    $('#grid').append('<li><a data-value="'+k+'">'+features[k].name+'</a></li>')
                };
                if (features[k].category == "txtbox"){
                    $('#txtbox').append('<li><a data-value="'+k+'">'+features[k].name+'</a></li>')
                };
                if (features[k].category == "media"){
                    $('#media').append('<li><a data-value="'+k+'">'+features[k].name+'</a></li>')
                };
              });

              $('#controls a').click(function(){
                var f = $(this).data('value');
                var cursorPos = $('#editarea').prop('selectionStart');
                var v = $('#editarea').val();
                var textBefore = v.substring(0,  cursorPos );
                var textAfter  = v.substring( cursorPos, v.length );
                $('#editarea').val( textBefore+ features[f].code +textAfter );
              });


              $('#contenu').append('<br />'+
                '<form action="/ajax/saveData/" id="saveSlideData">'+
                '<input type="hidden" name="currSlide" value="'+(curr-1)+'" />'+
                '<div class="form-group">'+
                '<textarea name="slideContent" class="form-control" rows="15" id="editarea">'+data.slides[curr-1].content+'</textarea>'+
                '</div>'+
                '<button type="submit" class="btn btn-default" id="submitchange">Submit</button>'+
                '</form>');

                $("#saveSlideData").on('submit', function (e) {
              e.preventDefault();
              var form = $("#saveSlideData");
              var url = form.attr("action");
                  $.post(url, form.serialize()).done(function (newData) {
                    data.slides[curr-1].content = newData;
                    $("#slideContent").html(newData);
                    form.find('textarea').val(newData);
                    $(function(){
                      $('[data-toggle="popover"]').popover()
                      });
                    });  
                  $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "/ajax/backup/",
                    data: {'jsonData': ''+ document.getElementById("editarea").value+ ''},
                    success: function(data){
                      alert(data);
                    },
                    error: function(e){
                      //console.log(e.message);
                    }
                  });
             }); 
        }else {
          // do nothing
        } 
    };
    var listmenus = "";
    for (var t = 0; t < data.menus.length; t++){
       listmenus += "<li class='dropdown-submenu'><a tabindex='0'>"+ data.menus[t].title + "</a><ul class='dropdown-menu' data-value=\""+data.menus[t].mod+"\"></ul></li>";
    }
    $(".dropdown-menu").html(listmenus);
    for (var s = 0; s < data.slides.length; s++){
        $(".dropdown-menu[data-value=" + data.slides[s].mod + "]").append("<li><a href='#' class='link' data-value=\""+s+"\" data-mod=" + data.slides[s].mod + " tabindex='0'>" + data.slides[s].title +"&nbsp;&nbsp;"+ "<span></span></a></li>");

    }
    // do admin only once
    if (adminaccess === true){
      $('.navbar-nav').append("<li><a id='adminpan'>Admin&nbsp;<span class='glyphicon glyphicon-cog'></span></a></li>");
      $("#adminpan").click(function(){
      $('body').html('<div class="container"></div>');
          $.ajax({
            url: "static/admin/cpanel.html",
            type: "GET",
            cache: false,
            success: function(html) {
                $(".container").html(html);
            }
          });
      });
    };     
    
    $(".nav .link").each(function() {
      realnav.push($(this).data("value"));
    });

    $(".nav .link").each(function() {
       modcurr.push($(this).data("mod"));
    });

    $('#closemodal').append(data.nav[4].text);

    $(".link").each(function(i){
        $(this).on("click", {x:i + 1}, function(event){
          curr=event.data.x;
          repnav();
          navcheck();
        });

    }); 

    $("#next_button").click(function(){
        curr++;
        repnav();
        navcheck();
    });

    $("#prev_button").click(function(){
        curr--;
        repnav();
        navcheck();
    });

    $('.misc').click(function(){
        $('.modal-header').html(data.misc[$(this).data("value")].title);
        $('.modal-body').html(data.misc[$(this).data("value")].content);
    });

repnav();
navcheck();
});



$('#progressbar').append('<div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width:0%"><span class="sr-only"></span></div>');

document.getElementById("navbottom").innerHTML =

    '<button id="prev_button"><span class="glyphicon glyphicon-chevron-left"></span>'+ data.nav[0].text +'</button>'+
    '<button id="next_button">'+ data.nav[1].text +'<span class="glyphicon glyphicon-chevron-right"></button>';


document.getElementById("titlecourse").innerHTML =
''+data.nav[5].text+'';
$('#titlecourse').append(' <span class="glyphicon glyphicon-menu-down"></span>');

function navcheck() {
  if (curr > totalslides) {
      curr = totalslides;
  }
  $.each(progression, function(i, el){
      if($.inArray(el, realprogress) === -1) realprogress.push(el);
  }); 

globalprogress = '['+realprogress+']'; 

  var viewed = realprogress.length * 100 / totalslides;
  var viewedint = parseInt(viewed);
  $('.progress-bar').attr('style', 'width:'+viewed+'%');
  $('.progress-bar').attr('aria-valuenow', viewed);
  $('.progress-bar').text(""+viewedint+"%");
var currlink = progression.slice(-1)[0];
$(".nav .link").each(function(t){
$('.link[data-value="'+realprogress[t]+'"] span').attr('class', 'glyphicon glyphicon-ok');
if (currlink == t){
$('.link[data-value="'+t+'"]').attr('style', 'background-color:#f5f5f5');
}else {
$('.link[data-value="'+t+'"]').attr('style', ''); 
}
  });

  if (curr-1 <=0){
 document.getElementById('prev_button').disabled = true;
  }
  else {
  document.getElementById('prev_button').disabled = false; 
  }
  if (curr-1 < totalslides){
 document.getElementById('next_button').disabled = false;   
  }
  if (curr == totalslides) {
  document.getElementById('next_button').disabled = true;
  }
  if (viewed >= 50){
    $('.progress-bar').removeClass("progress-bar-danger");
    $('.progress-bar').addClass("progress-bar-warning");
  }
if (viewed == 100){
    $('.progress-bar').removeClass("progress-bar-warning");
    $('.progress-bar').addClass("progress-bar-success");
    if (completed === false){
    complete();
    completed = true;
    }
  }
};

'use strict';

$(function() {
  $.ajax({
    success: function(data) {
      if (typeof data.stargazers_count != 'number') {
        return;
      }

      var html = '' +
        '<div class="input-group">' +
          '<div class="input-group-btn"></div>' +
          '<div class="input-group-addon">' +
            '<span>' + data.stargazers_count + '</span>' +
            '&nbsp;' +
            '<span class="fa fa-star"></span>' +
          '</div>' +
        '</div>';

      $('#gh-view-link').wrap(html);
    }
  });

  var containers = [
    document.body,
    document.documentElement
  ];

  var $scrollBtn = $('#scroll-top');

  function updateScrollBtnCls() {
    var scrollTop = containers.reduce(function(result, element) {
      return result + element.scrollTop;
    }, 0);

    $scrollBtn.toggleClass('hidden', scrollTop < 100);
  }

  $scrollBtn.on('click', function() {
    window.onscroll = null;

    $(this).addClass('hidden');

    $(containers).animate({
      scrollTop: 0
    }, 500, $.proxy(function() {
      window.onscroll = updateScrollBtnCls;
    }, this));
  });

  window.onscroll = updateScrollBtnCls;

  $('.dropdown > a[tabindex]').on('keydown', function(event) {


    if (event.keyCode == 13) {
      $(this).dropdown('toggle');
    }
  });

  $('.dropdown-menu').on('click', function(event) {
    if (this === event.target) {
      event.stopPropagation();
    }
  });

  $('[data-submenu]').submenupicker();

  updateScrollBtnCls();
});
    },
    error: function( data ) {
      if (adminaccess == true){
      $('#contenu').append('<h1>JSON ERROR</h1><div class="btn-group" role="group"><button type="button" class="btn btn-default dropdown-toggle" id="backfromdata" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Restore<span class="caret"></span></button><ul class="dropdown-menu" id="backuplist"></ul></div></div>');
      $('#backfromdata').click(function(){
  $.ajax({
            type: 'POST',
            url: 'admin/displaybackups.php',
            data: 'id=testdata',
            dataType: 'json',
            cache: false,
            success: function(result) {
              $('#backuplist').html('');
              for (var k=2; k < result.length; k++){
                $('#backuplist').append('<li><a data-value="'+k+'">'+result[k]+'</a></li>');
              }
              $('#backuplist a').click(function(){
                var selected = result[$(this).data('value')];
                if(confirm('Are you sure you want to back up from '+selected+' ?') == true){
                  //$.post('admin/usebackup.php', {name: selected});
                  window.location.href = "admin/usebackup.php?name=" + selected;
                  

                
                }else{
                //do nothing
                }
              })
            },
        });

});

      }else{
      $('#contenu').append('<h1>Course data failed to load</h1>'); 
	  console.log(data);
      }
 
    }
  });

<?php
$dt = new DateTime("now", new DateTimeZone('America/Toronto'));
$date = $dt->format('m_d_H.i.s');
$newfilename = "../data/backups/".$date.".json";
$files_in_directory = scandir('../data/backups');
$items_count = count($files_in_directory);

if ($items_count <= 21){
copy("../data/coursedata.json", $newfilename);
} else{
$updatefile = glob( '../data/backups/*.*' );
array_multisort(
array_map( 'filemtime', $updatefile ),
SORT_NUMERIC,
SORT_ASC,
$updatefile
);
$oldselect = reset($updatefile);
echo $oldselect;
rename($oldselect, $newfilename);
$file1 = "../data/coursedata.json";
copy($file1, $newfilename);
};
?>
<?php
$json_string = '../data/coursedata.json';
$jsondata = file_get_contents($json_string);
$obj = json_decode($jsondata,true);
$title = print_r($obj['nav'][5]['text'], true);
$myfile = fopen("../imsmanifest.xml", "w") or die("Unable to open file!");
$txt = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<manifest xmlns=\"http://www.imsproject.org/xsd/imscp_rootv1p1p2\" xmlns:imsmd=\"http://www.imsglobal.org/xsd/imsmd_rootv1p2p1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:adlcp=\"http://www.adlnet.org/xsd/adlcp_rootv1p2\" identifier=\"pipwerksWrapperSCORM12\" xsi:schemaLocation=\"http://www.imsproject.org/xsd/imscp_rootv1p1p2 imscp_rootv1p1p2.xsd http://www.imsglobal.org/xsd/imsmd_rootv1p2p1 imsmd_rootv1p2p1.xsd http://www.adlnet.org/xsd/adlcp_rootv1p2 adlcp_rootv1p2.xsd\">\r\n  <organizations default=\"pipwerks\">\r\n    <organization identifier=\"pipwerks\" structure=\"hierarchical\">\r\n      <title>".$title."</title>\r\n      <item identifier=\"SCORM12_wrapper_test\" isvisible=\"true\" identifierref=\"pipfiles\">\r\n        <title>".$title."</title>\r\n      </item>\r\n    </organization>\r\n  </organizations>\r\n  <resources>\r\n    <resource identifier=\"pipfiles\" type=\"webcontent\" adlcp:scormtype=\"sco\" href=\"index.html\">\r\n      <file href=\"index.html\" />\r\n      <file href=\"SCORM_API_wrapper.js\" />\r\n    </resource>\r\n  </resources>\r\n</manifest>";
fwrite($myfile, $txt);
fclose($myfile);
?>
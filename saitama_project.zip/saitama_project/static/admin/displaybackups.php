<?php
$dir    = '../data/backups/';
$files1 = scandir($dir);
echo json_encode($files1);
?>

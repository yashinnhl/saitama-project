<?php
$url = '../data/coursedata.json';


$slideContent = $_POST['slideContent'];
$currSlide = $_POST['currSlide'];

if($currSlide != null && $slideContent!= null) {
	$JSON = file_get_contents($url);
	$data = json_decode($JSON);
	
	//echo $currSlide . ": " . $slideContent;

	//echo $data->{"slides"}[$currSlide]->{'content'};
	
	$data->{"slides"}[$currSlide]->{'content'} = $slideContent;

	echo $data->{"slides"}[$currSlide]->{'content'};

	file_put_contents($url, json_encode($data));

} else {
	$jsonData = $_POST['jsonData'];
	
	echo $jsonData;
	
	if($jsonData!=null) {
		file_put_contents($url, json_encode($jsonData));
	}
	
}
?>
#this is saveData
import json
with open('data.txt', 'w') as outfile:
    json.dump(data, outfile)
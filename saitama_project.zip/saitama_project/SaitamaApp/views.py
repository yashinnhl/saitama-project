# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse
from SaitamaApp.models import Topic,Webpage,AccessRecord

# Create your views here.

def index(request):
    webpages_list = AccessRecord.objects.order_by('date')
    date_dict = {'access_records' : webpages_list}
    #my_dict = {'insert_me' : "Hello I am from hggh views.py !"}
    return render(request,'SaitamaApp/index.html', context=date_dict) #instead of my_dict
   #return HttpResponse("Hello Team awsome! <h1>this is saitama_project</h1>") // it was simple http response now we should create the templates as you can see in the above line

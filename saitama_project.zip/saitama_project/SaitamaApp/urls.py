# SaitamaApp urls
from django.conf.urls import url
from SaitamaApp import views

app_name = 'SaitamaApp' #this is for url tag

urlpatterns = [
		url(r'^$',views.index, name='index'),
          #if yu want you can add anotherpages here
		  # example: url(r'^relative',views.relative, name='relative'),
		]

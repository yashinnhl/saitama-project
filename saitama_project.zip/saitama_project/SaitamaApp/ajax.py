import json
from django.http import Http404, HttpResponse

def more_todo(request):
    if request.is_ajax():
        todo_items = ['Yasin', 'David',]
        data = json.dumps(todo_items)
        return HttpResponse(data, content_type='application/json')
    else:
        raise Http404

def add_todo(request):
    if request.is_ajax() and request.POST:
        data = {'message': "%s added" % request.POST.get('item')}
        #print(data)
        return HttpResponse(json.dumps(data), content_type='application/json')
    else:
        raise Http404
def backup(request):
    if request.is_ajax() and request.POST:
	    data = request.POST.get('jsonData')
	    #print('recieved' + json.dumps(data))
            writeInFile(data)
	    return HttpResponse(json.dumps(data), content_type='application/json')
    else:
        raise Http404


def saveData(request):
    if request.is_ajax() and request.POST:
	    data = request.POST.get('slideContent')
	    print('recieved' + json.dumps(data))
            writeInFileData(data)
	    return HttpResponse(json.dumps(data), content_type='application/json')
    else:
        raise Http404
		
def writeInFile(data):
    with open('static/data/backups/Backup.json', 'w') as outfile:
            json.dump(data, outfile)

def writeInFileData(data):
    with open('static/data/coursedata2.json', 'w') as outfile:
            json.dump(data, outfile)